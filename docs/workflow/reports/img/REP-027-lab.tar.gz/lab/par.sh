#!/bin/bash
# par.sh <exps.json> <out.jsonl> : runs experiments on 4 processes (round-robin by index)
EXP=$1; OUT=$2; N=$(python3 -c "import json,sys;print(len(json.load(open('$EXP'))))")
: > $OUT
cd /home/user/fruit-market
for w in 0 1 2 3; do
  IDX=$(python3 -c "print(' '.join(str(i) for i in range($N) if i%4==$w))")
  [ -n "$IDX" ] && (npx vite-node $(dirname $0)/run.ts $EXP $IDX >> $OUT.$w 2>&1; echo done >> $OUT.$w) &
done
wait
cat $OUT.[0-3] | grep '^{' >> $OUT; grep -h -v '^{\|^done' $OUT.[0-3] | head -5; rm -f $OUT.[0-3]
echo "results: $(wc -l < $OUT)"
