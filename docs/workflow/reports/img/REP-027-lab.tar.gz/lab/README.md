# REP-027 balance lab (archived; not part of the game build)

A copy of the rules engine (rules version 2, main 66bc299) with lab-only knobs, used for REP-027.
Defaults in engine/variant.ts reproduce production exactly (checked by parity.ts on 450 games).

Run from the repo root with the lab unpacked at <dir>:
  <dir>/lab/par.sh <dir>/lab/sweep6.json <dir>/lab/sweep6.jsonl   # 4 processes
  python3 <dir>/lab/s2.py <dir>/lab/sweep6.jsonl                    # summary table

- engine/variant.ts : rule knobs (demand/supply curve, capacity basis, trait and event options)
- engine/ai.ts      : production Hard AI plus "styles" (strategy plans) layered on top
- policies.ts       : strategy bots; run.ts: paired seeds with seat rotation, 95% intervals, lot economics
- sweep1-6.json     : experiment lists; *.jsonl results. Seeds 1-600 = development; 100001-102000 = held out.
