import { autoplay } from '/home/user/fruit-market/src/engine/ai';
import { newGame } from '/home/user/fruit-market/src/engine/game';
const t = Date.now();
for (let seed = 1; seed <= 200; seed++) autoplay(newGame({ players: Array.from({ length: 4 }, (_, i) => ({ name: 'P' + i, kind: 'ai' as const, level: 'hard' as const, avatar: '' })), days: 10, unripe: true, upgrades: true, events: true, seed }));
console.log('ms per 4p game', (Date.now() - t) / 200);
