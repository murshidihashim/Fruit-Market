import json,sys,collections
rows=[json.loads(l) for l in open(sys.argv[1])]
by=collections.defaultdict(dict)
for r in rows:
    tag,test=r['id'].split('|'); by[tag][test]=r
def w(d,test,k):
    try: return f"{d[test]['policies'][k]['winRate']:.0f}"
    except KeyError: return '-'
print("variant          | 3p vs 2 Hard: Und Salv Prem Resv Ripe Adap Turn Evnt | 4p Und Salv | skill2 skill3 | cash 2/3/4   | war3 war4 near3 | spoil3 hold-days3 | blow3 lead3 mid3 cmbk3 cmbk4 | mix4 T/R/Ri/E")
for t in by:
    d=by[t]; m3=d['mirror-3p']; a3=m3['policies']['ai']; m4=d['mirror-4p']
    lots=a3['lots']; held=sum(v['perGame']*v['sold']/100*v['holdDays'] for v in lots.values())/max(1e-9,sum(v['perGame']*v['sold']/100 for v in lots.values()))
    mix=d['mix4']['policies']
    print(f"{t:<16} | {w(d,'sUndercut-3p','sUndercut'):>16} {w(d,'sSalvage-3p','sSalvage'):>4} {w(d,'sPremium-3p','sPremium'):>4} {w(d,'sReserve-3p','sReserve'):>4} {w(d,'sRipen-3p','sRipen'):>4} {w(d,'sAdaptive-3p','sAdaptive'):>4} {w(d,'sTurnover-3p','sTurnover'):>4} {w(d,'sEvent-3p','sEvent'):>4} | {w(d,'sUndercut-4p','sUndercut'):>6} {w(d,'sSalvage-4p','sSalvage'):>4} {w(d,'sPremium-4p','sPremium'):>4} | {w(d,'skill-hard-normal-2p','ai'):>6} {w(d,'skill-hard-2normal-3p','ai'):>6} | {d['mirror-2p']['policies']['ai']['avgCash']:.0f}/{a3['avgCash']:.0f}/{m4['policies']['ai']['avgCash']:.0f} | {m3['game']['warShare']:>4} {m4['game']['warShare']:>4} {a3['nearMaxShare']:>5} | {a3['spoiled']:>5} {held:>5.2f} | {m3['game']['blowout']:>5} {m3['game']['leadChanges']:>5} {m3['game']['midLeaderWins']:>4} {m3['game']['comebackFromLast']:>5} {m4['game']['comebackFromLast']:>5} | {mix['sTurnover']['winRate']:.0f}/{mix['sReserve']['winRate']:.0f}/{mix['sRipen']['winRate']:.0f}/{mix['sEvent']['winRate']:.0f}")
