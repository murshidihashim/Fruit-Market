import { autoplay } from '/tmp/claude-0/-home-user/3c4a7f52-b2a0-51d3-95c0-8cf347da5d16/scratchpad/lab/engine/ai';
import { RIVALS } from '/tmp/claude-0/-home-user/3c4a7f52-b2a0-51d3-95c0-8cf347da5d16/scratchpad/lab/engine/data';
import { newGame, ranking, type Level } from '/tmp/claude-0/-home-user/3c4a7f52-b2a0-51d3-95c0-8cf347da5d16/scratchpad/lab/engine/game';
import { dailyConfig } from '/tmp/claude-0/-home-user/3c4a7f52-b2a0-51d3-95c0-8cf347da5d16/scratchpad/lab/engine/daily';
const G = 300;
import { setVariant } from '/tmp/claude-0/-home-user/3c4a7f52-b2a0-51d3-95c0-8cf347da5d16/scratchpad/lab/engine/variant';
import { FRUIT } from '/tmp/claude-0/-home-user/3c4a7f52-b2a0-51d3-95c0-8cf347da5d16/scratchpad/lab/engine/data';
if (process.env.PKG) { setVariant({ demandA: 0.6, demandB: 0.45, supplyA: 0.8, supplyB: 0.2, capacityBasis: 'base', demandByPlayers: { 2: 1, 3: 1, 4: 1.15 } }); FRUIT.apple.cost = { fresh: 3, okay: 2, notso: 1, unripe: 1 }; }
const LEAGUE: { title: string; rivals: { idx: number; level: Level }[]; days: number }[] = [
  { title: 'Village Square', rivals: [{ idx: 0, level: 'easy' }], days: 8 },
  { title: 'Harbour Steps', rivals: [{ idx: 2, level: 'easy' }, { idx: 4, level: 'easy' }], days: 8 },
  { title: 'Old Town', rivals: [{ idx: 1, level: 'normal' }], days: 10 },
  { title: 'Spice Lane', rivals: [{ idx: 3, level: 'normal' }, { idx: 5, level: 'normal' }], days: 10 },
  { title: 'Grand Bazaar', rivals: [{ idx: 1, level: 'hard' }, { idx: 0, level: 'normal' }], days: 10 },
  { title: 'Royal Market', rivals: [{ idx: 2, level: 'hard' }, { idx: 3, level: 'hard' }, { idx: 4, level: 'hard' }], days: 10 },
];
for (const me of ['easy', 'normal', 'hard'] as Level[]) {
  const rows: string[] = [];
  let all = 1;
  for (const st of LEAGUE) {
    let w = 0; let cash = 0;
    for (let seed = 1; seed <= G; seed++) {
      const s = autoplay(newGame({ players: [{ name: 'Me', kind: 'ai', level: me, avatar: '' }, ...st.rivals.map((r) => ({ ...RIVALS[r.idx], kind: 'ai' as const, level: r.level }))], days: st.days, unripe: true, upgrades: true, events: true, seed: seed * 977 }));
      if (ranking(s)[0] === 0) w++; cash += s.players[0].cash;
    }
    all *= w / G;
    rows.push(`${st.title} ${(100 * w / G).toFixed(0)}% (avg $${(cash / G).toFixed(0)}, expected tries ${(G / Math.max(1, w)).toFixed(1)})`);
  }
  let dw = 0;
  for (let k = 0; k < G; k++) {
    const c = dailyConfig(`2026-01-${String((k % 28) + 1).padStart(2, '0')}-${k}`, 'Me');
    c.players[0] = { ...c.players[0], kind: 'ai', level: me };
    if (ranking(autoplay(newGame(c)))[0] === 0) dw++;
  }
  console.log(`player=${me}: ${rows.join(' | ')} | daily win ${(100 * dw / G).toFixed(0)}%`);
}
