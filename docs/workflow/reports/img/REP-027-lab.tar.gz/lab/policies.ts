// Strategy bots for balance experiments. They use only public information, like the real computers.
// A policy = how it buys + how it prices + how it builds. 'ai' delegates to the current computer.
import { aiActFor, buyPhaseFavour, planBids, pickUpgrade, type Style } from './engine/ai';
import { FRUIT, FRUITS, UPGRADES, stageAt, type FruitId, type UpgradeId } from './engine/data';
import {
  activePlayer, allocate, bestCap, buy, buyCost, buyLimit, buyUpgrade, canBuy, canPlayFavour, canUpgrade, capAt, count,
  effectiveMax, endBuyTurn, endEvening, minPrice, playFavour, servingCustomers, shelfSize, submitBids, validateBids,
  walkInsToday, demandScale, type Bid, type GameState, type Level,
} from './engine/game';
import { CUSTOMER_CARDS } from './engine/data';

export type BuyStyle = 'ai' | 'forecast' | 'turnover' | 'ripen' | 'salvage' | 'volume';
export type PriceStyle = 'ai' | 'undercut' | 'margin' | 'adaptive';
export type BuildStyle = 'ai' | 'none' | UpgradeId[];
export interface Policy { name: string; level?: Level; buy: BuyStyle; price: PriceStyle; build: BuildStyle; style?: Partial<Style> }
const S = (name: string, style: Partial<Style>): Policy => ({ name, level: 'hard', buy: 'ai', price: 'ai', build: 'ai', style });

export const POLICIES: Record<string, Policy> = {
  ai: { name: 'ai', level: 'hard', buy: 'ai', price: 'ai', build: 'ai' },
  forecast: { name: 'forecast', buy: 'forecast', price: 'adaptive', build: 'ai' },
  turnover: { name: 'turnover', buy: 'turnover', price: 'undercut', build: ['signboard', 'cart'] },
  ripen: { name: 'ripen', buy: 'ripen', price: 'margin', build: ['coolroom', 'signboard'] },
  salvage: { name: 'salvage', buy: 'salvage', price: 'undercut', build: ['juicer', 'signboard'] },
  undercut: { name: 'undercut', level: 'hard', buy: 'ai', price: 'undercut', build: 'ai' },
  margin: { name: 'margin', level: 'hard', buy: 'ai', price: 'margin', build: 'ai' },
  adaptive: { name: 'adaptive', level: 'hard', buy: 'ai', price: 'adaptive', build: 'ai' },
  noupgrades: { name: 'noupgrades', level: 'hard', buy: 'ai', price: 'ai', build: 'none' },
  upgrader: { name: 'upgrader', level: 'hard', buy: 'ai', price: 'ai', build: ['signboard', 'coolroom', 'bell', 'cart', 'shelf', 'juicer'] },
  volume: { name: 'volume', buy: 'volume', price: 'undercut', build: ['cart', 'shelf', 'signboard'] },
  // Competent strategies: the Hard computer's core with a deliberate bias (how a skilled human plays a plan).
  sTurnover: S('sTurnover', { prefer: { blueberry: 1.15, watermelon: 1.08, apple: 0.85, mango: 0.95 }, oldBonus: 0.6, keep: 0, undercut: 1, unripeBonus: -1.5, buildOrder: ['signboard', 'cart', 'bell'] }),
  sReserve: S('sReserve', { prefer: { apple: 1.25, watermelon: 1.05, blueberry: 0.8, mango: 0.95 }, freshBonus: 0.4, keep: 0.45, undercut: 0, buildOrder: ['coolroom', 'signboard', 'shelf'] }),
  sRipen: S('sRipen', { prefer: { mango: 1.15, watermelon: 1.05, blueberry: 0.9 }, unripeBonus: 1.5, walkWeight: 0.7, keep: 0.3, buildOrder: ['signboard', 'coolroom', 'shelf'] }),
  sEvent: S('sEvent', { eventAware: 2.5, keep: 0.3, buildOrder: ['bell', 'signboard', 'coolroom'] }),
  sSalvage: S('sSalvage', { oldBonus: 0.8, keep: 0, undercut: 2, juiceAware: true, buildOrder: ['juicer', 'signboard', 'cart'] }),
  sUndercut: S('sUndercut', { undercut: 2, keep: 0 }),
  sPremium: S('sPremium', { undercut: 0, keep: 0.4, threshold: 0.6 }),
  sAdaptive: S('sAdaptive', { adaptive: true }),
  normal: { name: 'normal', level: 'normal', buy: 'ai', price: 'ai', build: 'ai' },
  easy: { name: 'easy', level: 'easy', buy: 'ai', price: 'ai', build: 'ai' },
  sLean: S('sLean', { maxBuys: 3, threshold: 0.8 }),
};

const ripeCount = (s: GameState, p: number, f: FruitId) => count(s.players[p].stock, f, true);

/** Demand the shop can see before customers arrive: waiting customers + the forecast + expected walk-ins. */
function knownDemand(s: GameState, f: FruitId, withWalkIns: boolean) {
  let q = 0, maxSum = 0;
  const cs = [...servingCustomers(s), ...(s.phase === 'buy' && s.forecast ? [s.forecast] : [])];
  for (const c of cs) for (const w of c.wants) if (w.fruit === f && w.qty > 0) { q += w.qty; maxSum += effectiveMax(s, w) * w.qty; }
  for (const w of s.event?.extra?.wants ?? []) if (w.fruit === f) { q += w.qty; maxSum += effectiveMax(s, w) * w.qty; }
  if (withWalkIns) {
    const ws = CUSTOMER_CARDS.flatMap((c) => c.wants).filter((w) => w.fruit === f);
    const per = ws.reduce((a, w) => a + w.qty, 0) / CUSTOMER_CARDS.length;
    const avgMax = ws.reduce((a, w) => a + w.max, 0) / ws.length;
    const walk = per * walkInsToday(s) * demandScale(s);
    q += walk; maxSum += avgMax * walk;
  }
  return { q, avgMax: q ? maxSum / q : 0 };
}

function othersStock(s: GameState, p: number, f: FruitId) {
  return s.players.reduce((a, _o, i) => (i === p ? a : a + ripeCount(s, i, f)), 0);
}

/** Fair share of visible demand this shop should hold, given rivals' visible stock and how many shops still buy. */
function share(s: GameState, p: number, f: FruitId, walk: boolean) {
  const d = knownDemand(s, f, walk);
  const n = s.players.length;
  const rivals = othersStock(s, p, f);
  const unbought = (s.order.length - 1 - s.turn) * 1.0; // rivals yet to buy will take some
  return { want: Math.max(0, Math.round((d.q - rivals - unbought * (d.q / Math.max(1, n * 2))) )), avgMax: d.avgMax };
}

type Pick = { f: FruitId; pos: number; score: number };

function pickBuy(s: GameState, p: number, style: BuyStyle): Pick | null {
  const pl = s.players[p];
  const daysLeft = s.config.days - s.day;
  let best: Pick | null = null;
  for (const f of FRUITS) {
    const ripeLen = FRUIT[f].ripe.length;
    const have = ripeCount(s, p, f);
    for (let pos = 0; pos < s.market[f].length; pos++) {
      if (canBuy(s, p, f, pos)) continue;
      const cost = buyCost(s, p, f, pos);
      const unripe = pos >= ripeLen;
      const ripenIn = unripe ? pos - (ripeLen - 1) : 0;
      let score = -Infinity;
      if (style === 'forecast') {
        // Only fresh-ish fruit for demand we can already see; no speculation on walk-ins.
        const sh = share(s, p, f, false);
        if (!unripe && have < sh.want) score = capAt(f, pos, sh.avgMax) - cost - (stageAt(f, pos) === 'fresh' ? 0 : 0.5);
      } else if (style === 'turnover') {
        // Cheapest fruit that can still sell today; sell it all today.
        const sh = share(s, p, f, true);
        if (!unripe && have < sh.want + 1) score = capAt(f, pos, sh.avgMax) - cost - 1 + (pos <= 1 ? 0.8 : 0);
      } else if (style === 'ripen') {
        // Unripe fruit that ripens in time, and durable apples; hold for full price.
        if (unripe && ripenIn <= daysLeft) {
          const avg = knownDemand(s, f, true).avgMax || 8;
          score = avg * 0.75 - cost - ripenIn * 0.4;
        } else if (!unripe && f === 'apple' && stageAt(f, pos) === 'fresh') {
          const sh = share(s, p, f, true);
          if (have < sh.want + 2) score = sh.avgMax - cost - 1.5;
        } else if (!unripe) {
          const sh = share(s, p, f, false);
          if (have < sh.want) score = capAt(f, pos, sh.avgMax) - cost - 1;
        }
      } else if (style === 'salvage') {
        // Cheap old fruit, sold cheap today; a Juice Press catches what doesn't sell.
        const sh = share(s, p, f, true);
        const cheap = cost <= 2;
        if (!unripe && cheap && have < sh.want + (pl.upgrades.includes('juicer') ? 2 : 0)) score = capAt(f, pos, sh.avgMax) - cost - 0.5;
      } else if (style === 'volume') {
        const sh = share(s, p, f, true);
        if (!unripe && have < sh.want + 2) score = capAt(f, pos, sh.avgMax) - cost - 1.5;
      }
      if (score > (best?.score ?? 0.3)) best = { f, pos, score };
    }
  }
  return best;
}

// ---------- pricing ----------

/** How far below its cap each rival priced on average in past showdowns (public: offers are revealed). */
function rivalDiscount(s: GameState, r: number): number {
  const hist = s.history ?? [];
  let sum = 0, n = 0;
  for (const d of hist.slice(-4)) for (const l of d.lines) for (const o of l.offers) {
    if (o.player !== r) continue;
    sum += Math.max(0, l.max - o.price); n++;
  }
  return n ? sum / n : 2;
}

function planPrices(s: GameState, p: number, style: PriceStyle): { bids: Bid[]; favoured: boolean } {
  if (style === 'ai') return planBids(s, p);
  const pl = s.players[p];
  const stock = JSON.parse(JSON.stringify(pl.stock));
  const lastDay = s.day >= s.config.days;
  const lines = servingCustomers(s).flatMap((c) => c.wants.filter((w) => w.qty > 0).map((w) => ({ c, w, max: effectiveMax(s, w) }))).sort((a, b) => b.max - a.max);
  const bids: Bid[] = [];
  let contested = false;
  for (const { c, w, max } of lines) {
    const f = w.fruit;
    const myCap = bestCap(stock, f, max);
    if (myCap <= 0) continue;
    const rivals = s.players.map((o, i) => ({ i, cap: i === p ? 0 : bestCap(o.stock, f, max), n: i === p ? 0 : count(o.stock, f, true) })).filter((r) => r.n > 0 && r.cap > 0);
    const rotting = stock[f][0] > 0;
    const floor = minPrice(s, f);
    let price = myCap;
    if (rivals.length) {
      contested = true;
      const rivalUnits = rivals.reduce((a, r) => a + r.n, 0);
      const crowded = rivalUnits >= w.qty;
      if (style === 'undercut') price = Math.min(myCap, Math.min(...rivals.map((r) => r.cap)) - 1);
      else if (style === 'margin') price = rotting || lastDay ? Math.min(myCap, Math.min(...rivals.map((r) => r.cap)) - 1) : myCap - (crowded ? 1 : 0);
      else if (style === 'adaptive') {
        const predicted = Math.min(...rivals.map((r) => Math.max(1, r.cap - Math.round(rivalDiscount(s, r.i)))));
        const hold = rotting || lastDay ? 1 : Math.ceil(myCap * 0.55);
        price = crowded ? Math.max(hold, Math.min(myCap, predicted - 1)) : Math.min(myCap, Math.max(predicted, hold));
      }
    }
    price = Math.max(floor, Math.round(price));
    if (style === 'margin' && !rotting && !lastDay && price < myCap * 0.6) continue; // hold instead of dumping
    let qty = Math.min(w.qty, count(stock, f, true));
    let used: number[] | null = null;
    while (qty > 0 && !(used = allocate(stock, f, qty, price, max))) qty--;
    if (!used || qty <= 0) continue;
    for (const i of used) stock[f][i]--;
    bids.push({ customerId: c.id, fruit: f, qty, price });
  }
  while (bids.length && validateBids(s, p, bids)) bids.pop();
  return { bids, favoured: contested && pl.favours.includes('favouredTrade') && !pl.favouredTrade };
}

// ---------- building ----------

function pickBuild(s: GameState, p: number, style: BuildStyle): UpgradeId | null {
  if (style === 'ai') return pickUpgrade(s, p);
  if (style === 'none') return null;
  const pl = s.players[p];
  const left = s.config.days - s.day;
  for (const u of style) {
    if (canUpgrade(s, p, u)) continue;
    if (left < 2) continue;
    if (pl.cash - UPGRADES[u].cost < 5) continue;
    return u;
  }
  return null;
}

/** One action for player p under policy pol (it must be p's turn). */
export function act(s: GameState, p: number, pol: Policy): GameState {
  if (pol.style || (pol.buy === 'ai' && pol.price === 'ai' && pol.build === 'ai')) return aiActFor(s, p)!;
  const pl = s.players[p];
  if (s.phase === 'buy') {
    if (pol.buy === 'ai') return aiActFor(s, p)!;
    const fav = buyPhaseFavour(s, p);
    if (fav) return fav;
    if (pl.boughtToday < buyLimit(pl) && count(pl.stock) < shelfSize(pl)) {
      const pick = pickBuy(s, p, pol.buy);
      if (pick) return buy(s, p, pick.f, pick.pos);
    }
    return endBuyTurn(s, p);
  }
  if (s.phase === 'bid') {
    const { bids, favoured } = planPrices(s, p, pol.price);
    return submitBids(s, p, bids, favoured);
  }
  if (s.phase === 'evening') {
    const pi = pl.favours.indexOf('priority');
    if (pi >= 0 && !canPlayFavour(s, p, pi) && s.priorityNext === null) return playFavour(s, p, pi);
    const u = pickBuild(s, p, pol.build);
    if (u) return buyUpgrade(s, p, u);
    return endEvening(s, p);
  }
  throw new Error('no action in ' + s.phase);
}

export { activePlayer };
