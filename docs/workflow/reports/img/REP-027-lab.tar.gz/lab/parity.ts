import * as P from '/home/user/fruit-market/src/engine/ai';
import * as PG from '/home/user/fruit-market/src/engine/game';
import * as L from './engine/ai';
import * as LG from './engine/game';
let diff = 0;
for (let seed = 1; seed <= 150; seed++) for (const n of [2, 3, 4]) {
  const cfg = { players: Array.from({ length: n }, (_, i) => ({ name: 'P' + i, kind: 'ai' as const, level: (['easy', 'normal', 'hard'] as const)[(i + seed) % 3], avatar: '' })), days: [8, 10, 14][seed % 3], unripe: true, upgrades: true, events: true, seed };
  const a = P.autoplay(PG.newGame(cfg)).players.map((p) => p.cash).join(',');
  const b = L.autoplay(LG.newGame(cfg)).players.map((p) => p.cash).join(',');
  if (a !== b) diff++;
}
console.log('games compared', 450, 'differences', diff);
