// Experiment runner: node(vite-node) run.ts <experiments.json> [index ...]
// Each experiment: { id, n, days, policies[], seeds:[from,to], variant?, data?, traits?: 'random'|TraitId[] }
// Seats rotate through the policy list per seed, so every policy plays every seat equally often.
import { readFileSync } from 'fs';
import { beginBuying, finishReveal, newGame, ranking, count, marketCost, activePlayer, pickTrait, type GameState, type Level } from './engine/game';
import { CUSTOMER_CARDS, EVENT_CARDS, FRUIT, FRUITS, UPGRADES, TRAITS, type TraitId } from './engine/data';
import { setVariant, setHooks, type Variant } from './engine/variant';
import { act, POLICIES, type Policy } from './policies';
import { STYLE } from './engine/ai';

interface DataPatch {
  fruit?: Record<string, Partial<{ cost: Record<string, number>; drop: number[]; ripe: string[]; unripeSlots: number }>>;
  priceShift?: Record<string, number>; // added to every customer's top price for that fruit
  upgrades?: Record<string, { cost: number }>;
  events?: Record<string, Record<string, unknown>>;
}
export interface Exp { id: string; n: number; days: number; policies: string[]; seeds: [number, number]; variant?: Partial<Variant>; data?: DataPatch; traits?: 'random' | TraitId[]; focus?: string }

const ORIG = {
  fruit: JSON.parse(JSON.stringify(FRUIT)),
  cards: JSON.parse(JSON.stringify(CUSTOMER_CARDS)),
  upgrades: JSON.parse(JSON.stringify(UPGRADES)),
  events: JSON.parse(JSON.stringify(EVENT_CARDS)),
};
function applyData(d: DataPatch = {}) {
  for (const f of FRUITS) Object.assign(FRUIT[f], JSON.parse(JSON.stringify(ORIG.fruit[f])), d.fruit?.[f] ?? {});
  CUSTOMER_CARDS.forEach((c, i) => c.wants.forEach((w, k) => { w.max = ORIG.cards[i].wants[k].max + (d.priceShift?.[w.fruit] ?? 0); }));
  for (const u of Object.keys(UPGRADES)) Object.assign((UPGRADES as any)[u], ORIG.upgrades[u], d.upgrades?.[u] ?? {});
  EVENT_CARDS.forEach((e, i) => {
    Object.keys(e).forEach((k) => delete (e as any)[k]);
    Object.assign(e, JSON.parse(JSON.stringify(ORIG.events[i])), d.events?.[ORIG.events[i].id] ?? {});
  });
}

const zero = () => Object.fromEntries(FRUITS.map((f) => [f, 0])) as Record<string, number>;
function newAgg() {
  return { games: 0, wins: 0, cash: 0, cash2: 0, gap: 0, gap2: 0, sold: 0, spoiled: 0, juiced: 0, juiceCash: 0, unsoldEnd: 0, broke: 0,
    bought: zero(), boughtCost: zero(), boughtStage: {} as Record<string, number>, soldBy: zero(), revenue: zero(), capSum: zero(), warSales: 0, nearMax: 0,
    upgrades: {} as Record<string, number>, upgradeDay: {} as Record<string, number>, traits: {} as Record<string, [number, number]>, lots: {} as Record<string, number[]> };
}

function run(e: Exp) {
  setVariant(e.variant ?? {});
  applyData(e.data);
  const pols: Policy[] = e.policies.map((k) => POLICIES[k] ?? (() => { throw new Error('policy ' + k); })());
  const per: Record<string, ReturnType<typeof newAgg>> = {};
  for (const k of e.policies) per[k] ??= newAgg();
  const G = { games: 0, margin: [] as number[], close: 0, blowout: 0, leadChanges: 0, d5LeaderWins: 0, comeback: 0, ties: 0, incomeByDay: [] as number[][], brokeTurns: 0, warSales: 0, sales: 0, paired: [] as number[] };
  const focus = e.focus ?? e.policies[0];
  for (let seed = e.seeds[0]; seed <= e.seeds[1]; seed++) {
    const n = e.n;
    const seatPol = Array.from({ length: n }, (_, i) => e.policies[(i + seed) % e.policies.length]);
    let s: GameState = newGame({
      players: seatPol.map((k, i) => ({ name: `P${i}`, kind: (Array.isArray(e.traits) ? 'human' : 'ai') as 'human' | 'ai', level: (POLICIES[k].level ?? 'hard') as Level, avatar: '' })),
      days: e.days, unripe: true, upgrades: true, events: true, seed,
    });
    if (Array.isArray(e.traits)) {
      // traits[i] goes to the seat playing policies[i] this seed (so a trait follows its policy round the table)
      e.traits.forEach((t, i) => { const seat = ((i - seed) % n + n) % n; s.players[seat].traitOffer = [t]; s = pickTrait(s, seat, t); });
      s.players.forEach((pl) => { pl.kind = 'ai'; });
    }
    const tr = { boughtStage: [] as string[] };
    void tr;
    // Lot tracking (FIFO per shelf slot): what each purchase stage eventually earned.
    const shadow: { st: string; cost: number; day: number }[][][] = s.players.map((pl) => FRUITS.map((f) => pl.stock[f].map(() => [] as { st: string; cost: number; day: number }[])));
    const FI = (f: string) => FRUITS.indexOf(f as any);
    const lotRec = (p: number, key: string) => { const a = per[seatPol[p]]; return (a.lots[key] ??= [0, 0, 0, 0, 0, 0]); };
    setHooks({
      age: (p, f, steps) => { const t = shadow[p][FI(f)]; for (let k = 0; k < steps; k++) { const gone = t.shift()!; t.push([]); for (const lot of gone) { const L2 = lotRec(p, lot.st); L2[0]++; L2[2] -= lot.cost; L2[4]++; } } },
      buy: (p, f, pos, cost) => {
        const st = `${f}:${pos >= FRUIT[f as keyof typeof FRUIT].ripe.length ? 'unripe' : FRUIT[f as keyof typeof FRUIT].ripe[pos]}`;
        shadow[p][FI(f)][pos].push({ st, cost, day: s.day });
        const a = per[seatPol[p]]; a.bought[f]++; a.boughtCost[f] += cost; a.boughtStage[st] = (a.boughtStage[st] ?? 0) + 1;
      },
      sell: (p, f, used, price, max, day) => {
        const a = per[seatPol[p]]; a.soldBy[f] += used.length; a.revenue[f] += used.length * price; a.capSum[f] += used.length * max;
        if (price <= 2) { a.warSales += used.length; G.warSales += used.length; } if (price >= max - 1) a.nearMax += used.length; G.sales += used.length;
        for (const pos of used) { const lot = shadow[p][FI(f)][pos].shift(); if (!lot) continue; const L2 = lotRec(p, lot.st); L2[0]++; L2[1]++; L2[2] += price - lot.cost; L2[3] += day - lot.day; }
      },
      spoil: (p, _f, n2) => { per[seatPol[p]].spoiled += n2; },
      juice: (p, n2, v) => { per[seatPol[p]].juiced += n2; per[seatPol[p]].juiceCash += v; },
    });
    Object.keys(STYLE).forEach((k) => delete STYLE[+k]);
    seatPol.forEach((k, i) => { if (POLICIES[k].style) STYLE[i] = POLICIES[k].style!; });
    const cashByDay: number[][] = [];
    for (let i = 0; i < 30000 && s.phase !== 'over'; i++) {
      if (s.phase === 'morning') {
        const cheapest = Math.min(...FRUITS.flatMap((f) => s.market[f].map((q, pos) => (q > 0 ? marketCost(s, f, pos) : 99))));
        s.players.forEach((pl, k) => { if (pl.cash < cheapest && count(pl.stock, undefined, true) === 0) { per[seatPol[k]].broke++; G.brokeTurns++; } });
        s = beginBuying(s); continue;
      }
      if (s.phase === 'reveal') {
        const inc = s.results!.income; (G.incomeByDay[s.day - 1] ??= []).push(inc.reduce((a, b) => a + b, 0) / n);
        s = finishReveal(s); cashByDay.push(s.players.map((p) => p.cash)); continue;
      }
      const p = activePlayer(s);
      s = act(s, p, POLICIES[seatPol[p]]);
    }
    if (s.phase !== 'over') throw new Error('did not finish ' + e.id + ' seed ' + seed);
    shadow.forEach((pp, p) => pp.forEach((slots) => slots.forEach((lots) => lots.forEach((lot) => { const L2 = lotRec(p, lot.st); L2[0]++; L2[2] -= lot.cost; L2[5]++; }))));
    const r = ranking(s);
    const cash = s.players.map((p) => p.cash);
    const sorted = [...cash].sort((a, b) => b - a);
    G.games++; G.margin.push(sorted[0] - sorted[1]);
    if (sorted[0] - sorted[1] <= 3) G.close++;
    if (sorted[0] - sorted[1] >= 20) G.blowout++;
    if (sorted[0] === sorted[1]) G.ties++;
    const leaders = cashByDay.map((c) => c.indexOf(Math.max(...c)));
    for (let d = 1; d < leaders.length; d++) if (leaders[d] !== leaders[d - 1]) G.leadChanges++;
    const mid = Math.floor(e.days / 2) - 1;
    if (leaders[mid] === r[0]) G.d5LeaderWins++;
    const dm = cashByDay[mid];
    if (dm && dm.indexOf(Math.min(...dm)) === r[0]) G.comeback++;
    s.players.forEach((pl, k) => {
      const a = per[seatPol[k]];
      a.games++; if (r[0] === k) a.wins++;
      a.cash += pl.cash; a.cash2 += pl.cash * pl.cash;
      const others = cash.filter((_, i) => i !== k);
      const gap = pl.cash - others.reduce((x, y) => x + y, 0) / others.length;
      a.gap += gap; a.gap2 += gap * gap;
      a.sold += pl.stats.sold; a.unsoldEnd += count(pl.stock, undefined, true);
      for (const u of pl.upgrades) a.upgrades[u] = (a.upgrades[u] ?? 0) + 1;
      if (pl.trait) { a.traits[pl.trait] ??= [0, 0]; a.traits[pl.trait][1]++; if (r[0] === k) a.traits[pl.trait][0]++; }
      if (seatPol[k] === focus && k === s.players.findIndex((_, j) => seatPol[j] === focus)) G.paired.push(gap);
    });
  }
  setHooks({});
  const out: Record<string, unknown> = { id: e.id, n: e.n, days: e.days, games: G.games };
  const pct = (a: number, b: number) => +(100 * a / Math.max(1, b)).toFixed(1);
  const ci = (p: number, N: number) => +(196 * Math.sqrt(Math.max(1e-9, p * (1 - p)) / Math.max(1, N))).toFixed(1);
  out.policies = Object.fromEntries(Object.entries(per).map(([k, a]) => {
    const wr = a.wins / Math.max(1, a.games);
    const gm = a.gap / a.games, gsd = Math.sqrt(Math.max(0, a.gap2 / a.games - gm * gm));
    const boughtTot = Object.values(a.bought).reduce((x, y) => x + y, 0);
    const fruit = Object.fromEntries(FRUITS.map((f) => [f, {
      bought: +(a.bought[f] / a.games).toFixed(1), sold: +(a.soldBy[f] / a.games).toFixed(1),
      avgCost: +(a.boughtCost[f] / Math.max(1, a.bought[f])).toFixed(2), avgSale: +(a.revenue[f] / Math.max(1, a.soldBy[f])).toFixed(2),
      saleVsCap: pct(a.revenue[f], a.capSum[f]),
      netPerBought: +((a.revenue[f] - a.boughtCost[f]) / Math.max(1, a.bought[f])).toFixed(2),
    }]));
    return [k, {
      games: a.games, winRate: pct(a.wins, a.games), winCI: ci(wr, a.games), avgCash: +(a.cash / a.games).toFixed(1),
      gap: +gm.toFixed(1), gapCI: +(1.96 * gsd / Math.sqrt(a.games)).toFixed(1),
      sold: +(a.sold / a.games).toFixed(1), bought: +(boughtTot / a.games).toFixed(1), spoiled: +(a.spoiled / a.games).toFixed(2), juiced: +(a.juiced / a.games).toFixed(2), unsoldEnd: +(a.unsoldEnd / a.games).toFixed(2),
      warShare: pct(a.warSales, a.sold), nearMaxShare: pct(a.nearMax, a.sold), brokeMornings: +(a.broke / a.games).toFixed(2),
      lots: Object.fromEntries(Object.entries(a.lots).map(([k2, L2]) => [k2, { perGame: +(L2[0] / a.games).toFixed(2), sold: pct(L2[1], L2[0]), netPerUnit: +(L2[2] / Math.max(1, L2[0])).toFixed(2), holdDays: +(L2[3] / Math.max(1, L2[1])).toFixed(2), spoiled: pct(L2[4], L2[0]), unsoldEnd: pct(L2[5], L2[0]) }])),
      fruit, stages: Object.fromEntries(Object.entries(a.boughtStage).map(([k2, v]) => [k2, +(v / a.games).toFixed(2)])),
      upgrades: Object.fromEntries(Object.entries(a.upgrades).map(([u, c]) => [u, +(c / a.games).toFixed(2)])),
      traits: Object.fromEntries(Object.entries(a.traits).map(([t, [w, c]]) => [t, `${pct(w, c)}% of ${c}`])),
    }];
  }));
  const med = [...G.margin].sort((a, b) => a - b)[Math.floor(G.margin.length / 2)];
  out.game = {
    medianMargin: med, close: pct(G.close, G.games), blowout: pct(G.blowout, G.games), ties: pct(G.ties, G.games),
    leadChanges: +(G.leadChanges / G.games).toFixed(2), midLeaderWins: pct(G.d5LeaderWins, G.games), comebackFromLast: pct(G.comeback, G.games),
    warShare: pct(G.warSales, G.sales), brokeTurnsPerGame: +(G.brokeTurns / G.games).toFixed(2),
    incomeByDay: G.incomeByDay.map((x) => +(x.reduce((a, b) => a + b, 0) / x.length).toFixed(1)),
    focusGaps: G.paired.length ? undefined : undefined,
  };
  out.focusGapSeries = G.paired; // per-seed gap for the focus policy (for paired comparisons)
  return out;
}

const file = process.argv[2];
const idx = process.argv.slice(3).map(Number);
const exps: Exp[] = JSON.parse(readFileSync(file, 'utf8'));
for (const [i, e] of exps.entries()) {
  if (idx.length && !idx.includes(i)) continue;
  const t = Date.now();
  const res = run(e);
  console.log(JSON.stringify({ ...res, ms: Date.now() - t }));
}
void TRAITS;
