import json,sys
rows=[json.loads(l) for l in open(sys.argv[1])]
rows.sort(key=lambda r:r['id'])
for r in rows:
    g=r['game']; P=r['policies']
    if r['id'].startswith('vsai'):
        foc=r['id'].split('-')[1]; a=P[foc]
        fr=' '.join(f"{f[:2]}{v['bought']}" for f,v in a['fruit'].items())
        print(f"{r['id']:<22} win {a['winRate']:>5}±{a['winCI']:<4} (fair {round(100/r['n'])}) gap {a['gap']:>6}±{a['gapCI']:<4} | sold {a['sold']} spoil {a['spoiled']} unsold {a['unsoldEnd']} war {a['warShare']}% nearMax {a['nearMaxShare']}% buys[{fr}] upg {a['upgrades']}")
    else:
        print(f"{r['id']} ({r['n']}p, {r['games']} games): " + ' | '.join(f"{k} win {a['winRate']}±{a['winCI']} gap {a['gap']}" for k,a in P.items()) + f" || war {g['warShare']}% margin {g['medianMargin']} lead {g['leadChanges']}")
