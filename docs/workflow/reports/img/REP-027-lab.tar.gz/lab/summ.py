import json,sys
rows=[json.loads(l) for l in open(sys.argv[1])]
rows.sort(key=lambda r:r['id'])
for r in rows:
    g=r['game']; P=r['policies']
    if len(P)==1:
        a=list(P.values())[0]
        fr=' '.join(f"{f[:3]} b{v['bought']}/s{v['sold']} c{v['avgCost']} p{v['avgSale']} net{v['netPerBought']} cap%{v['saleVsCap']}" for f,v in a['fruit'].items())
        print(f"{r['id']:<22} cash {a['avgCash']} sold {a['sold']} spoil {a['spoiled']} unsoldEnd {a['unsoldEnd']} war {g['warShare']}% nearMax {a['nearMaxShare']}% | margin {g['medianMargin']} close {g['close']} blow {g['blowout']} lead {g['leadChanges']} midLeader {g['midLeaderWins']} comeback {g['comebackFromLast']} broke {g['brokeTurnsPerGame']}")
        print('   ',fr)
        print('    upg',a['upgrades'],'income',g['incomeByDay'])
    else:
        foc=r['id'].split('-')[1]; a=P[foc]; b=P.get('ai')
        print(f"{r['id']:<22} {foc:<10} win {a['winRate']}±{a['winCI']} (fair {round(100/r['n'],1)}) gap {a['gap']}±{a['gapCI']} cash {a['avgCash']} vs ai {b['avgCash'] if b else '-'} | sold {a['sold']} bought {a['bought']} spoil {a['spoiled']} juiced {a['juiced']} unsold {a['unsoldEnd']} war {a['warShare']}% nearMax {a['nearMaxShare']}% broke {a['brokeMornings']} upg {a['upgrades']}")
