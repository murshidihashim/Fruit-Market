import json,sys,collections
rows=[json.loads(l) for l in open(sys.argv[1])]
by=collections.defaultdict(dict)
for r in rows:
    tag,test=r['id'].split('|'); by[tag][test]=r
order=sorted(by, key=lambda t: list(by).index(t))
def w(r,k): a=r['policies'][k]; return f"{a['winRate']:.0f}"
hdr="variant                 Und3 Und4 Salv3 Prem3 Resv3 Ripe3 Adap3 | hardVsNorm2 | cash2/3/4      | war3 war4 | nearMax3 | spoil3 | blow3 lead3 cmbk4 | broke4"
print(hdr)
for t in sorted(by):
    d=by[t]
    try:
        m2,m3,m4=d['mirror-2p'],d['mirror-3p'],d['mirror-4p']
        a3=m3['policies']['ai']; a4=m4['policies']['ai']
        print(f"{t:<23} {w(d['sUndercut-3p'],'sUndercut'):>4} {w(d['sUndercut-4p'],'sUndercut'):>4} {w(d['sSalvage-3p'],'sSalvage'):>5} {w(d['sPremium-3p'],'sPremium'):>5} {w(d['sReserve-3p'],'sReserve'):>5} {w(d['sRipen-3p'],'sRipen'):>5} {w(d['sAdaptive-3p'],'sAdaptive'):>5} | {w(d['skill-hard-normal-2p'],'ai'):>11} | {m2['policies']['ai']['avgCash']:.0f}/{a3['avgCash']:.0f}/{a4['avgCash']:.0f} | {m3['game']['warShare']:>4} {m4['game']['warShare']:>4} | {a3['nearMaxShare']:>8} | {a3['spoiled']:>6} | {m3['game']['blowout']:>5} {m3['game']['leadChanges']:>5} {m4['game']['comebackFromLast']:>5} | {m4['game']['brokeTurnsPerGame']}")
    except KeyError as e: print(t,'missing',e)
