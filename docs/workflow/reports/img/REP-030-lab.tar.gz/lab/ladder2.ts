// League stage probe for the final PLAN-012 package. Usage: vite-node ladder2.ts <variantName>
import { autoplay } from './engine/ai';
import { FRUIT, RIVALS } from './engine/data';
import { newGame, ranking, type Level } from './engine/game';
import { dailyConfig } from './engine/daily';
import { setVariant } from './engine/variant';
setVariant({ demandA: 0.6, demandB: 0.45, supplyA: 0.8, supplyB: 0.2, capacityBasis: 'base', demandByPlayers: { 2: 1, 3: 1, 4: 1.15 },
  hagglerMode: 'beforeFreshness', favouriteTip: 4, nesteggBonus: 5, deliveryForecast: true, juiceBar: 1 });
FRUIT.apple.cost = { fresh: 3, okay: 2, notso: 1, unripe: 1 };
FRUIT.mango.cost = { fresh: 4, okay: 2, notso: 1, unripe: 3 };
type St = { title: string; rivals: { idx: number; level: Level }[]; days: number };
const LEAGUES: Record<string, St[]> = {
  current: [
    { title: 'Village Square', rivals: [{ idx: 0, level: 'easy' }], days: 8 },
    { title: 'Harbour Steps', rivals: [{ idx: 2, level: 'easy' }, { idx: 4, level: 'easy' }], days: 8 },
    { title: 'Old Town', rivals: [{ idx: 1, level: 'normal' }], days: 10 },
    { title: 'Spice Lane', rivals: [{ idx: 3, level: 'normal' }, { idx: 5, level: 'normal' }], days: 10 },
    { title: 'Grand Bazaar', rivals: [{ idx: 1, level: 'hard' }, { idx: 0, level: 'normal' }], days: 10 },
    { title: 'Royal Market', rivals: [{ idx: 2, level: 'hard' }, { idx: 3, level: 'hard' }, { idx: 4, level: 'hard' }], days: 10 },
  ],
  L2: [
    { title: 'Village Square', rivals: [{ idx: 0, level: 'easy' }], days: 8 },
    { title: 'Harbour Steps', rivals: [{ idx: 2, level: 'easy' }], days: 8 },
    { title: 'Old Town', rivals: [{ idx: 1, level: 'easy' }, { idx: 4, level: 'easy' }], days: 10 },
    { title: 'Spice Lane', rivals: [{ idx: 3, level: 'normal' }], days: 10 },
    { title: 'Grand Bazaar', rivals: [{ idx: 1, level: 'normal' }, { idx: 0, level: 'normal' }], days: 10 },
    { title: 'Royal Market', rivals: [{ idx: 2, level: 'hard' }, { idx: 3, level: 'normal' }, { idx: 4, level: 'normal' }], days: 10 },
  ],
  L3: [
    { title: 'Village Square', rivals: [{ idx: 0, level: 'easy' }], days: 8 },
    { title: 'Harbour Steps', rivals: [{ idx: 2, level: 'easy' }, { idx: 4, level: 'easy' }], days: 8 },
    { title: 'Old Town', rivals: [{ idx: 1, level: 'normal' }], days: 10 },
    { title: 'Spice Lane', rivals: [{ idx: 3, level: 'normal' }, { idx: 5, level: 'easy' }], days: 10 },
    { title: 'Grand Bazaar', rivals: [{ idx: 1, level: 'normal' }, { idx: 0, level: 'normal' }], days: 10 },
    { title: 'Royal Market', rivals: [{ idx: 2, level: 'hard' }, { idx: 3, level: 'hard' }, { idx: 4, level: 'normal' }], days: 10 },
  ],
};
const G = 300;
const LEAGUE = LEAGUES[process.argv[2] ?? 'current'];
for (const me of ['easy', 'normal', 'hard'] as Level[]) {
  const rows: string[] = [];
  for (const st of LEAGUE) {
    let w = 0;
    for (let seed = 1; seed <= G; seed++) {
      const s = autoplay(newGame({ players: [{ name: 'Me', kind: 'ai', level: me, avatar: '' }, ...st.rivals.map((r) => ({ ...RIVALS[r.idx], kind: 'ai' as const, level: r.level }))], days: st.days, unripe: true, upgrades: true, events: true, seed: seed * 977 }));
      if (ranking(s)[0] === 0) w++;
    }
    rows.push(`${st.title} ${(100 * w / G).toFixed(0)}%`);
  }
  let dw = 0;
  for (let k = 0; k < G; k++) {
    const c = dailyConfig(`2026-01-${String((k % 28) + 1).padStart(2, '0')}-${k}`, 'Me');
    c.players[0] = { ...c.players[0], kind: 'ai', level: me };
    if (ranking(autoplay(newGame(c)))[0] === 0) dw++;
  }
  console.log(`${process.argv[2] ?? 'current'} player=${me}: ${rows.join(' | ')} | daily ${(100 * dw / G).toFixed(0)}%`);
}
