// Average daily delivery and customer demand per day stage, for the v3 formulas vs the tabletop rules.
import { autoplay } from './engine/ai';
import { FRUIT } from './engine/data';
import { newGame, beginBuying, type GameState } from './engine/game';
import { setVariant } from './engine/variant';
const F = { demandA: 0.6, demandB: 0.45, supplyA: 0.8, supplyB: 0.2, capacityBasis: 'base' as const, demandByPlayers: { 2: 1, 3: 1, 4: 1.15 }, hagglerMode: 'beforeFreshness' as const, favouriteTip: 4, nesteggBonus: 5, deliveryForecast: true, juiceBar: 1 };
FRUIT.apple.cost = { fresh: 3, okay: 2, notso: 1, unripe: 1 }; FRUIT.mango.cost = { fresh: 4, okay: 2, notso: 1, unripe: 3 };
for (const tt of [false, true]) {
  setVariant({ ...F, tabletop: tt });
  for (const n of [2, 3, 4]) {
    const sup = [0, 0], dem = [0, 0], days = [0, 0];
    for (let seed = 1; seed <= 100; seed++) {
      const seen = new Set<number>();
      let s: GameState = newGame({ players: Array.from({ length: n }, (_, i) => ({ name: 'P' + i, kind: 'ai' as const, level: 'hard' as const, avatar: '' })), days: 10, unripe: true, upgrades: true, events: false, seed });
      while (s.phase !== 'over') {
        if (s.phase === 'morning') { const h = s.day <= 5 ? 0 : 1; sup[h] += Object.values(s.delivery).reduce((a, b) => a + (b ?? 0), 0); days[h]++; s = beginBuying(s); continue; }
        if (s.phase === 'bid' && !seen.has(s.day)) { const h = s.day <= 5 ? 0 : 1; dem[h] += s.firstMarket.reduce((a, c) => a + c.original.reduce((b, w) => b + w.qty, 0), 0); seen.add(s.day); }
        s = autoplay(s, 1);
      }
    }
    console.log(tt ? 'tabletop' : 'v3      ', `${n}p`, 'supply/day early', (sup[0] / days[0]).toFixed(1), 'late', (sup[1] / days[1]).toFixed(1), '| demand/day early', (dem[0] / days[0]).toFixed(1), 'late', (dem[1] / days[1]).toFixed(1), '| buy cap', 4 * n);
  }
}
