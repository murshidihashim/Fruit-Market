// Parity: production engine (rules version 3) against the lab with the final PLAN-012 package switched on.
import * as P from '/home/user/fruit-market/src/engine/ai';
import * as PG from '/home/user/fruit-market/src/engine/game';
import * as L from './engine/ai';
import * as LG from './engine/game';
import { FRUIT } from './engine/data';
import { setVariant } from './engine/variant';
setVariant({ demandA: 0.6, demandB: 0.45, supplyA: 0.8, supplyB: 0.2, capacityBasis: 'base', demandByPlayers: { 2: 1, 3: 1, 4: 1.15 },
  hagglerMode: 'beforeFreshness', favouriteTip: 4, nesteggBonus: 5, deliveryForecast: true, juiceBar: 1 });
FRUIT.apple.cost = { fresh: 3, okay: 2, notso: 1, unripe: 1 };
FRUIT.mango.cost = { fresh: 4, okay: 2, notso: 1, unripe: 3 };
let diff = 0; let first = '';
for (let seed = 1; seed <= 150; seed++) for (const n of [2, 3, 4]) {
  const cfg = { players: Array.from({ length: n }, (_, i) => ({ name: 'P' + i, kind: 'ai' as const, level: (['easy', 'normal', 'hard'] as const)[(i + seed) % 3], avatar: '' })), days: [8, 10, 14][seed % 3], unripe: true, upgrades: true, events: true, seed };
  const a = P.autoplay(PG.newGame(cfg)).players.map((p) => p.cash).join(',');
  const b = L.autoplay(LG.newGame(cfg)).players.map((p) => p.cash).join(',');
  if (a !== b) { diff++; if (!first) first = `seed ${seed} n ${n}: prod ${a} lab ${b}`; }
}
console.log('games compared', 450, 'differences', diff, first);
