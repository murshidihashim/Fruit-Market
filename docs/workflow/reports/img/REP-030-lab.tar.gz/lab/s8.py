import json, sys, collections
rows = [json.loads(l) for l in open(sys.argv[1])]
G = collections.defaultdict(dict)
for r in rows:
    t, k = r['id'].split('|')
    ps = r['policies']
    if k == 'mix4':
        G[t][k] = '/'.join(f"{ps[p]['winRate']:.0f}" for p in ('sTurnover', 'sReserve', 'sRipen', 'sEvent'))
    elif k.startswith('mirror'):
        a = ps['ai']
        G[t][k] = f"cash {a['avgCash']} upg {a['upgrades']} juiced {a['juiced']} traits {a['traits']}"
    elif k.startswith('skill'):
        G[t][k] = ps['ai']['winRate']
    else:
        f = k[:-3]
        G[t][k] = f"{ps[f]['winRate']} (${ps[f]['avgCash']:.0f})"
for t in sorted(G):
    print(t)
    for k, v in sorted(G[t].items()):
        print('   ', k, v)
