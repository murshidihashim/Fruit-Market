// Lab-only rule knobs. Defaults reproduce the production rules exactly.
export const BASE = {
  demandA: 0.4, demandB: 0.45, supplyA: 1, supplyB: 0.5,
  demandByPlayers: { 2: 1, 3: 1, 4: 1 } as Record<number, number>,
  supplyByPlayers: { 2: 1, 3: 1, 4: 1 } as Record<number, number>,
  capacityBasis: 'actual' as 'actual' | 'base',
  walkThreshold: 0.5,
  juiceCap: 3, juiceValue: 2, juiceEnd: 0, juiceMode: 'spoil' as 'spoil' | 'last2' | 'any', coolMode: 'alternate' as 'alternate' | 'freeze', juiceBar: 0, tabletop: false, pulse: false, posted: false, pulseGlut: 1, marketDays: 0, marketDayExtra: 2, marketDayNoLorry: false, noNightFinal: false,
  endSalvage: 0,
  unripeCutoff: false,
  hagglerMode: 'current' as 'current' | 'beforeFreshness',
  basketMode: 'buy' as 'buy' | 'buyShelf',
  bargainDiscount: 1, bargainMinCost: 0,
  favouriteTip: 3, nesteggBonus: 6, charmerCards: 3, freeCash: 3, signTip: 1,
  brokeCredit: false,
  valueRanking: false,
  deliveryForecast: false,
  forecastAware: 1,
};
export type Variant = typeof BASE;
export const V: Variant = JSON.parse(JSON.stringify(BASE));
export function setVariant(patch: Partial<Variant>) {
  const fresh = JSON.parse(JSON.stringify(BASE));
  Object.keys(V).forEach((k) => delete (V as any)[k]);
  Object.assign(V, fresh, patch);
}

/** Lab instrumentation: called by the engine on economic events. */
export interface Hooks {
  buy?(p: number, f: string, pos: number, cost: number, day: number): void;
  sell?(p: number, f: string, positions: number[], price: number, max: number, day: number): void;
  spoil?(p: number, f: string, n: number, day: number): void;
  juice?(p: number, n: number, value: number, day: number): void;
  age?(p: number, f: string, steps: number): void;
}
export const HOOK: Hooks = {};
export function setHooks(h: Hooks) { Object.keys(HOOK).forEach((k) => delete (HOOK as any)[k]); Object.assign(HOOK, h); }
